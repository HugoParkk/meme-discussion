import styled from "styled-components"
const Background = styled.div`

background-image: linear-gradient(to right, #FF50E2, white 20%, white 80%, #FF50E2); 
`

export default Background;