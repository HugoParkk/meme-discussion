import React from "react";

function GradeChart() {
  return <div>GradeChart</div>;
}

export default GradeChart;
