import React from "react";

function GradeBoardHeader() {
  return <div>gradeBoardHeader</div>;
}

export default GradeBoardHeader;
