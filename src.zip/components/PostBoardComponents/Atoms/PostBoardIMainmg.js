import React from "react";
import styled from "styled-components";
import svg from "../../../images/Group 306.svg";
function PostBoardIMainmg() {
  return <Image src={svg}></Image>;
}
const Image = styled.img`
  width: 350px;
`;
export default PostBoardIMainmg;
