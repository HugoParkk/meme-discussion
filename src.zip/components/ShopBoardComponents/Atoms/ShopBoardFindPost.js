import React from "react";
import styled from "styled-components";
import GlobalStyle from "../GlobalStyle";

function ShopBoardFindPost() {
  // return (
  //   <>
  //     <GlobalStyle />
  //     <Text type={"text"} placeholder={"검색어를 입력해주세요"}></Text>
  //   </>
  // );
}
const Text = styled.input`
  font-size: 0.8vw;
  color: #C0C0C0;
  width: 15.625vw;
  font-weight: bold;
  height: 1.95vw;
  margin-left: 0.721vw;
  padding-left: 1vw;
  padding-top: 0.06vw;
  border: 0.1vw solid #dbdbdb;
  position: relative;
  display: flex;
`;

export default ShopBoardFindPost;
